/*

https://cses.fi/problemset/task/1696

There are n boys and m girls in a school. Next week a school dance will be organized. A dance pair consists of a boy and a girl, and there are k potential pairs.
Your task is to find out the maximum number of dance pairs and show how this number can be achieved.

Input:
	The first input line has three integers n, m and k: the number of boys, girls, and potential pairs. The boys are numbered 1,2,\dots,n, and the girls are numbered 1,2,\dots,m.
	After this, there are k lines describing the potential pairs. Each line has two integers a and b: boy a and girl b are willing to dance together.

Output:
	First print one integer r: the maximum number of dance pairs. After this, print r lines describing the pairs. You can print any valid solution.

Constraints:
	1 <= n,m <= 500
	1 <= k <= 1000
	1 <= a <= n
	1 <= b <= m

Example

Input:
3 2 4
1 1
1 2
2 1
3 1

Output:
2
1 2
3 1

*/

#define OFFLINE_EXECUTION 0

#if OFFLINE_EXECUTION
#define _CRT_SECURE_NO_WARNINGS  1
#endif

#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

long long bfs(int n, vector<vector<int>>& adjList, vector<vector<long long>>& capacity)
{
	int curr, next;
	long long flow, out;
	vector<int> parent(adjList.size(), -1);
	parent[0] = -2;
	queue<int> q_node;
	queue<long long> q_flow;

	q_node.push(0);
	q_flow.push(numeric_limits<long long>::max());

	while (!q_node.empty())
	{
		curr = q_node.front();
		q_node.pop();
		flow = q_flow.front();
		q_flow.pop();
		for (unsigned int i = 0; i < adjList[curr].size(); i++)
		{
			next = adjList[curr][i];
			if (parent[next] == -1 && capacity[curr][next] > 0)
			{
				parent[next] = curr;
				out = min(flow, capacity[curr][next]);
				if (next == n)
				{
					while (next != 0)
					{
						curr = parent[next];
						capacity[curr][next] -= out;
						capacity[next][curr] += out;
						next = curr;
					}
					return out;
				}
				q_node.push(next);
				q_flow.push(out);
			}
		}
	}
	return 0;
}


int main()
{
	long long out = 0;
	int n, m, k, i, a, b;
	long long curr_flow;
#if OFFLINE_EXECUTION
	(void*)freopen("input.txt", "r", stdin);
#endif
	cin >> n >> m >> k;
	vector<vector<int>> adjList(n + m + 2);
	vector<vector<long long>> capacity(n + m + 2, vector<long long>(n + m + 2, 0));

	for(i = 1; i <= n; i++)
	{
		adjList[0].push_back(i);
		adjList[i].push_back(0);
		capacity[0][i] = 1;
	}
	for (; i <= n+m; i++)
	{
		adjList[n+m+1].push_back(i);
		adjList[i].push_back(n + m + 1);
		capacity[i][n + m + 1] = 1;
	}
	for (i = 0; i < k; i++)
	{
		cin >> a >> b;
		if(capacity[a][n + b] == 0)
		{
			adjList[a].push_back(n + b);
			adjList[n + b].push_back(a);
			capacity[a][n + b] = 1;
		}
	}
	curr_flow = bfs(n + m + 1, adjList, capacity);
	while (curr_flow > 0)
	{
		out += curr_flow;
		curr_flow = bfs(n + m + 1, adjList, capacity);
	}
	cout << out << endl;

	for (int i = 1; i <= n; i++)
	{
		for (unsigned int j = 0; j < adjList[i].size(); j++)
		{
			if (adjList[i][j] == 0 || adjList[i][j] == n + m + 1)
			{
				continue;
			}

			if (capacity[0][i] == 0 && capacity[i][adjList[i][j]] == 0 && capacity[adjList[i][j]][n+m+1] == 0)
			{
				cout << i << " " << adjList[i][j] - n << endl;
			}
		}
	}

#if OFFLINE_EXECUTION
	fclose(stdin);
#endif
	return 0;
}