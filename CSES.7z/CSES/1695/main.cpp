/*

https://cses.fi/problemset/task/1695

Kaaleppi has just robbed a bank and is now heading to the harbor. However, the police wants to stop him by closing some streets of the city.
What is the minimum number of streets that should be closed so that there is no route between the bank and the harbor?

Input:
	The first input line has two integers n and m: the number of crossings and streets. The crossings are numbered 1,2,\dots,n. The bank is located at crossing 1, and the harbor is located at crossing n.
	After this, there are m lines that describing the streets. Each line has two integers a and b: there is a street between crossings a and b. All streets are two-way streets, and there is at most one street between two crossings.
Output:
	First print an integer k: the minimum number of streets that should be closed. After this, print k lines describing the streets. You can print any valid solution.
	Constraints

2 <= n <= 500
1 <= m <= 1000
1 <= a,b <= n

Example

Input:
4 5
1 2
1 3
2 3
3 4
1 4

Output:
2
3 4
1 4

*/

#define OFFLINE_EXECUTION 0

#if OFFLINE_EXECUTION
#define _CRT_SECURE_NO_WARNINGS  1
#endif

#include <iostream>
#include <vector>
#include <queue>
#include <limits>

using namespace std;

long long bfs(int n, vector<vector<int>>& adjList, vector<vector<long long>>& capacity)
{
	int curr, next;
	long long flow, out;
	vector<int> parent(adjList.size(), -1);
	parent[1] = -2;
	queue<int> q_node;
	queue<long long> q_flow;

	q_node.push(1);
	q_flow.push(numeric_limits<long long>::max());

	while (!q_node.empty())
	{
		curr = q_node.front();
		q_node.pop();
		flow = q_flow.front();
		q_flow.pop();
		for (unsigned int i = 0; i < adjList[curr].size(); i++)
		{
			next = adjList[curr][i];
			if (parent[next] == -1 && capacity[curr][next] > 0)
			{
				parent[next] = curr;
				out = min(flow, capacity[curr][next]);
				if (next == n)
				{
					while (next != 1)
					{
						curr = parent[next];
						capacity[curr][next] -= out;
						capacity[next][curr] += out;
						next = curr;
					}
					return out;
				}
				q_node.push(next);
				q_flow.push(out);
			}
		}
	}
	return 0;
}


int main()
{
	long long out = 0;
	int n, m, i, a, b;
	long long curr_flow;
#if OFFLINE_EXECUTION
	(void*)freopen("input.txt", "r", stdin);
#endif
	cin >> n >> m;
	vector<vector<int>> adjList(n + 1);
	vector<vector<long long>> capacity(n + 1, vector<long long>(n + 1, 0));

	for (i = 0; i < m; i++)
	{
		cin >> a >> b;
		adjList[a].push_back(b);
		adjList[b].push_back(a);
		capacity[a][b] = 1;
		capacity[b][a] = 1;
	}
	curr_flow = bfs(n, adjList, capacity);
	while (curr_flow > 0)
	{
		out += curr_flow;
		curr_flow = bfs(n, adjList, capacity);
	}
	cout << out << endl;
	queue<int> q_node;
	vector<bool> visited(n + 1, false);
	q_node.push(1);
	visited[1] = true;
	while (!q_node.empty())
	{
		a = q_node.front();
		q_node.pop();
		for (unsigned int i = 0; i < adjList[a].size(); i++)
		{
			b = adjList[a][i];
			if (!visited[b] && capacity[a][b] > 0)
			{
				visited[b] = true;
				q_node.push(b);
			}

		}
	}

	for (int i = 1; i < n; i++)
	{
		for (unsigned int j = 0; j < adjList[i].size(); j++)
		{
			if (visited[i] && !visited[adjList[i][j]])
			{
				cout << i << " " << adjList[i][j] << endl;
			}
		}
	}

#if OFFLINE_EXECUTION
	fclose(stdin);
#endif
	return 0;
}