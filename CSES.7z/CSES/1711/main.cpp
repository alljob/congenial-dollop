/*

https://cses.fi/problemset/task/1711

A game consists of n rooms and m teleporters. At the beginning of each day, you start in room 1 and you have to reach room n.
You can use each teleporter at most once during the game. How many days can you play if you choose your routes optimally?

Input:
	The first input line has two integers n and m: the number of rooms and teleporters. The rooms are numbered 1,2,\dots,n.
	After this, there are m lines describing the teleporters. Each line has two integers a and b: there is a teleporter from room a to room b.
	There are no two teleporters whose starting and ending room are the same.
Output:
	First print an integer k: the maximum number of days you can play the game. Then, print k route descriptions according to the example. You can print any valid solution.

Constraints:

2 <= n <= 500
1 <= m <= 1000
1 <= a,b <= n

Example

Input:
6 7
1 2
1 3
2 6
3 4
3 5
4 6
5 6

Output:
2
3
1 2 6
4
1 3 4 6

*/

#define OFFLINE_EXECUTION 1

#if OFFLINE_EXECUTION
#define _CRT_SECURE_NO_WARNINGS  1
#endif

#include <iostream>
#include <vector>
#include <queue>
#include <limits>
#include <stack>

using namespace std;

long long bfs(int n, vector<vector<int>>& adjList, vector<vector<long long>>& capacity)
{
	int curr, next;
	long long flow, out;
	vector<int> parent(adjList.size(), -1);
	parent[1] = -2;
	queue<int> q_node;
	queue<long long> q_flow;

	q_node.push(1);
	q_flow.push(numeric_limits<long long>::max());

	while (!q_node.empty())
	{
		curr = q_node.front();
		q_node.pop();
		flow = q_flow.front();
		q_flow.pop();
		for (unsigned int i = 0; i < adjList[curr].size(); i++)
		{
			next = adjList[curr][i];
			if (parent[next] == -1 && capacity[curr][next] > 0)
			{
				parent[next] = curr;
				out = min(flow, capacity[curr][next]);
				if (next == n)
				{
					while (next != 1)
					{
						curr = parent[next];
						capacity[curr][next] -= out;
						capacity[next][curr] += out;
						next = curr;
					}
					return out;
				}
				q_node.push(next);
				q_flow.push(out);
			}
		}
	}
	return 0;
}


int main()
{
	long long out = 0;
	int n, m, i, a, b;
	long long curr_flow;
#if OFFLINE_EXECUTION
	freopen("input.txt", "r", stdin);
#endif
	cin >> n >> m;
	vector<vector<int>> adjList(n + 1);
	vector<vector<long long>> capacity(n + 1, vector<long long>(n + 1, 0));

	for (i = 0; i < m; i++)
	{
		cin >> a >> b;
		if (capacity[a][b] == 0 && capacity[b][a] == 0)
		{
			adjList[a].push_back(b);
			adjList[b].push_back(a);
		}
		capacity[a][b]++;
	}

	curr_flow = bfs(n, adjList, capacity);
	while (curr_flow > 0)
	{
		out += curr_flow;
		curr_flow = bfs(n, adjList, capacity);
	}

	cout << out << endl;
	for (int j = 0; j < out; j++)
	{
		queue<int> q;
		vector<int> p(n + 1, -1);
		stack<int> st;
		q.push(1);
		p[1] = -2;
		while (!q.empty())
		{
			a = q.front();
			q.pop();
			for (i = 0; i < adjList[a].size(); i++)
			{
				b = adjList[a][i];
				if (p[b] == -1 && capacity[a][b] == 0)
				{
					p[b] = a;
					if (b == n)
					{
						capacity[a][b] = 1;
						st.push(b);
						while (b != 1)
						{
							a = p[b];
							capacity[a][b] = 1;
							b = a;
							st.push(b);
						}
						cout << st.size() << endl;
						while (!st.empty())
						{
							cout << st.top();
							st.pop();
							if (!st.empty())
							{
								cout << " ";
							}
						}
						cout << endl;
					}
					else
					{
						q.push(b);
					}
				}
			}
		}
	}

#if OFFLINE_EXECUTION
	fclose(stdin);
#endif
	return 0;
}